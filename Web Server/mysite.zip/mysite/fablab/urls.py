from django.conf.urls import url

from . import views
from django.views.generic import TemplateView

urlpatterns = [
	# /index
    url(r'^$', views.index2, name='index2'),
    url(r'^index/$', views.index2, name='index2'),
    url(r'^index.html/$', views.index, name='index'),
    # /index2
    url(r'^index2/$', views.index2, name='index2'),
    
    #url(r'^(?P<machine_id>[0-9]+)/$', views.detail, name='detail'),
    #url(r'^results/$', views.detail2, name='detail2'),
    #url(r'^drinks/(?P<drink_name>\D+)/', TemplateView.as_view(template_name='fablab/index.html')),
    
    # /testpage
    url(r'^testpage/$', views.testpage, name='testpage'),
    
    # /users
    url(r'^users/$', views.users, name='users'),
    # /users/<user_name>
    url(r'^users/(?P<user_name>\D+)/$', views.detail_user,),
    # /new-user
    url(r'^new-user/$', views.new_user),
    # /register-user
    url(r'^register-user/$', views.register_user),
    # /register-machine
    url(r'^register-machine/$', views.register_machine),
    # /machines
    url(r'^machines/$', views.machines, name='machines'),
    # /machines/<machine_name>
    url(r'^machines/(?P<machine_name>\D+)/$', views.detail_machine,),
    # /new-machine
    url(r'^new-machine/$', views.new_machine),
    # /login/
    url(r'^login/$', views.login_view, name='login'),
    # /logout/
    url(r'^logout/$', views.logout_view, name='logout'),
]
