# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, render_to_response

from django.template import RequestContext
from django.http import HttpResponseRedirect, HttpResponse, Http404
from django.core.urlresolvers import reverse
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout

from .models import Machine, Machine_User, CardID

from .forms import RegisterFormUser, RegisterFormMachine


def index(request):
    latest_machine_list = Machine.objects.order_by('-machine_name')
    context = { 'latest_machine_list': latest_machine_list }
    return render(request, 'fablab/index.html', context)

def index2(request):
    latest_machine_list = Machine.objects.order_by('-machine_name')
    context = { 'latest_machine_list': latest_machine_list }
    return render(request, 'fablab/index2.html', context)

def login_view(request):
    # Like before, obtain the context for the user's request.
    context = RequestContext(request)

    # If the request is a HTTP POST, try to pull out the relevant information.
    if request.method == 'POST':
        # Gather the username and password provided by the user.
        # This information is obtained from the login form.
        username = request.POST['username']
        password = request.POST['password']

        # Use Django's machinery to attempt to see if the username/password
        # combination is valid - a User object is returned if it is.
        user = authenticate(username=username, password=password)

        # If we have a User object, the details are correct.
        # If None (Python's way of representing the absence of a value), no user
        # with matching credentials was found.
        if user:
            # Is the account active? It could have been disabled.
            if user.is_active:
                # If the account is valid and active, we can log the user in.
                # We'll send the user back to the homepage.
                login(request, user)
                return HttpResponseRedirect('/fablab/machines/')
            else:
                # An inactive account was used - no logging in!
                return HttpResponse("Your SmartLab account is disabled.")
        else:
            # Bad login details were provided. So we can't log the user in.
            print "Invalid login details: {0}, {1}".format(username, password)
            return HttpResponse("Invalid login details supplied. GTFO")

    # The request is not a HTTP POST, so display the login form.
    # This scenario would most likely be a HTTP GET.
    else:
        # No context variables to pass to the template system, hence the
        # blank dictionary object...
        return HttpResponseRedirect('/fablab/index2/')

@login_required(login_url='/fablab/index2')
def register_user(request):
	# if this is a POST request we need to process the form data
	if request.method == 'POST':
		# create a form instance and populate it with data from the request:
		form = RegisterFormUser(request.POST)
		# check whether it's valid:
		if form.is_valid():
			# process the data in form.cleaned_data as required
			firstname = form.cleaned_data['firstname']
			surname = form.cleaned_data['surname']
			user = Machine_User.objects.filter(first_name__exact = firstname, last_name__exact = surname)
			if user.exists():
				return HttpResponse("This name already exists")
			else:
				u = Machine_User(first_name=firstname, last_name=surname)
				u.save()
				# redirect to a new URL:
				user_list = Machine_User.objects.order_by('id')
				context = { 'user_list': user_list }
				return render(request, 'fablab/user-list.html', context)
				
	# if a GET (or any other method) we'll create a blank form
	else:
		form = RegisterFormUser()

	return render(request, 'fablab/new-user.html', {'form': form})

@login_required(login_url='/fablab/index2')
def register_machine(request):
	# if this is a POST request we need to process the form data
	if request.method == 'POST':
		# create a form instance and populate it with data from the request:
		form = RegisterFormMachine(request.POST)
		# check whether it's valid:
		if form.is_valid():
			# process the data in form.cleaned_data as required
			machineName = form.cleaned_data['machineName']
			machine = Machine.objects.filter(machine_name__exact = machineName)
			if machine.exists():
				return HttpResponse("This machine already exists")
			else:
				u = Machine_User.objects.filter(first_name__exact='Kali', last_name__exact='Linux')
				m = Machine(machine_name=machineName, machine_user=u[0])
				m.save()
				# redirect to a new URL:
				machine_list = Machine.objects.order_by('id')
				context = { 'machine_list': machine_list }
				return render(request, 'fablab/machine-list.html', context)
				
	# if a GET (or any other method) we'll create a blank form
	else:
		form = RegisterFormMachine()

	return render(request, 'fablab/new-machine.html', {'form': form})

@login_required(login_url='/fablab/index2')
def logout_view(request):

    # Since we know the user is logged in, we can now just log them out.
    logout(request)

    # Take the user back to the homepage.
    return HttpResponseRedirect('/fablab/index2/')

@login_required(login_url='/fablab/index2')
def users(request):
	context = {}
	try:
		user_list = Machine_User.objects.order_by('id')
		context = { 'user_list': user_list }
	except Machine_User.DoesNotExist:
		raise Http404("Machine_User does not exist")
	return render(request, 'fablab/user-list.html', context)

@login_required(login_url='/fablab/index2')
def machines(request):
	context = {}
	try:
		machine_list = Machine.objects.order_by('id')
		context = { 'machine_list': machine_list }
	except Machine.DoesNotExist:
		raise Http404("You have no machines listed. So sad!")
	return render(request, 'fablab/machine-list.html', context)
    
@login_required(login_url='/fablab/index2')
def detail(request, machine_id):
    return HttpResponse("You're looking at machine %s." % machine_id)

@login_required(login_url='/fablab/index2')
def testpage(request):
	machine_list = Machine.objects.all()
	user_list = Machine_User.objects.all()
	context = { 'machine_list': machine_list, 'user_list' : user_list }
	return render(request, 'fablab/testpage.html', context)

@login_required(login_url='/fablab/index2')
def detail2(request):
    machine_name = request.GET['machine_name']
    return HttpResponse("You're looking at machine %s." % machine_name)

@login_required(login_url='/fablab/index2')
def detail_machine(request, machine_name):
	context = {}
	try:
		machine = Machine.objects.get(machine_name__exact = machine_name)
		context = { 'machine': machine }
	except Machine.DoesNotExist:
		raise Http404("This machine does not exist")
	return render(request, 'fablab/machine-details.html', context)

@login_required(login_url='/fablab/index2')
def detail_user(request, user_name):
	context = {}
	try:
		user_name = user_name.split()
		user = Machine_User.objects.filter(first_name__exact = user_name[0], last_name__exact = user_name[1])
		user = user[0]
		context = { 'user': user }
	except IndexError:
		raise Http404("Machine_User does not exist")
	return render(request, 'fablab/user-details.html', context)

@login_required(login_url='/fablab/index2')
def new_user(request):
	form = RegisterFormUser(request.POST)
	return render(request, 'fablab/new-user.html', {'form': form})

@login_required(login_url='/fablab/index2')
def new_machine(request):
	form = RegisterFormMachine(request.POST)
	return render(request, 'fablab/new-machine.html', {'form': form})
	
